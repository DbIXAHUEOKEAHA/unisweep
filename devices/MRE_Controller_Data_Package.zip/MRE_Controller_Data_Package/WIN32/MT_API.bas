'VB�ӿ��ļ�
'4.4

Option Explicit

Public Const R_OK =0
Public Const RUN_OFF =0
Public Const RUN_ON =1
Public Const DIR_NEG =0
Public Const DIR_POS =1
Public Const LIMIT_ON =1
Public Const LIMIT_OFF =0
Public Const RESOURCE_MOTOR =&H00000001
Public Const RESOURCE_TTL_IN =&H00000002
Public Const RESOURCE_TTL_OUT =&H00000004
Public Const RESOURCE_OPTIC_IN =&H00000008
Public Const RESOURCE_OPTIC_OUT =&H00000010
Public Const RESOURCE_AD =&H00000020
Public Const RESOURCE_OC =&H00000040
Public Const RESOURCE_LINE =&H00000080
Public Const RESOURCE_CIRCLE =&H00000100
Public Const RESOURCE_PLC =&H00000200
Public Const RESOURCE_STREAM =&H00000400
Public Const RESOURCE_ENCODER =&H00000800
Public Const RESOURCE_PWM =&H00001000
Public Const RESOURCE_T =&H00002000
Public Const RESOURCE_TRIGGER =&H00004000

'//**************************************************//
'// V4.3 updated 2020-04-24
'//**************************************************//
'//==================================================
'//���л���
'//===================================================
'//dll�汾
'//��ʼ������
Declare Function MT_Init Lib "MT_API.dll" () As Long

'//�رմ���
Declare Function MT_DeInit Lib "MT_API.dll" () As Long

'//��ȡdll�汾��
Declare Function MT_Get_Dll_Version Lib "MT_API.dll" (ByRef sVer As String) As Long

'//�����߳���ʱ��
Declare Function MT_Set_Thread_Timeout Lib "MT_API.dll" (ByVal ms As Long) As Long

'//======================================================
'//ͨ�ſ�
'//======================================================
'//�� UART
Declare Function MT_Open_UART Lib "MT_API.dll" (ByVal sCOM As String) As Long

Declare Function MT_Open_UART_Unicode Lib "MT_API.dll" (ByVal sCOM As String) As Long

Declare Function MT_M_Open_UART Lib "MT_API.dll" (ByVal ADev As Long,ByVal sCOM As String) As Long

Declare Function MT_M_Open_UART_Unicode Lib "MT_API.dll" (ByVal ADev As Long,ByVal sCOM As String) As Long

Declare Function MT_Open_UART_ID Lib "MT_API.dll" (ByVal AID As Long) As Long

'//�ر� UART
Declare Function MT_Close_UART Lib "MT_API.dll" () As Long

Declare Function MT_M_Close_UART Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//��USB,��ϵͳ˳��
Declare Function MT_Open_USB Lib "MT_API.dll" () As Long

Declare Function MT_M_Open_USB Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//��USB�������к�ָ��
Declare Function MT_M_Open_USB_SN Lib "MT_API.dll" (ByVal ADev As Long,ByVal ASN As String) As Long

'//�ر�USB
Declare Function MT_Close_USB Lib "MT_API.dll" () As Long

Declare Function MT_M_Close_USB Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//������
Declare Function MT_Open_Net Lib "MT_API.dll" (ByVal IP0 As Byte,ByVal IP1 As Byte,ByVal IP2 As Byte,ByVal IP3 As Byte,ByVal IPPort As Integer) As Long

Declare Function MT_M_Open_Net Lib "MT_API.dll" (ByVal ADev As Long,ByVal IP0 As Byte,ByVal IP1 As Byte,ByVal IP2 As Byte,ByVal IP3 As Byte,ByVal IPPort As Integer) As Long

'//2021 04 20 �ַ�������IP����������
Declare Function MT_Open_Net_Name Lib "MT_API.dll" (ByVal IP_or_Name As String,ByVal IPPort As Integer) As Long

Declare Function MT_M_Open_Net_Name Lib "MT_API.dll" (ByVal ADev As Long,ByVal IP_or_Name As String,ByVal IPPort As Integer) As Long

'//�ر�����
Declare Function MT_Close_Net Lib "MT_API.dll" () As Long

Declare Function MT_M_Close_Net Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//=====================================================
'//�忨���
'//=====================================================
'//����豸
Declare Function MT_Check Lib "MT_API.dll" () As Long

Declare Function MT_M_Check Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//��ȡ��Դģ��
Declare Function MT_Get_Product_Resource Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Product_Resource Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//��ȡID
Declare Function MT_Get_Product_ID Lib "MT_API.dll" (ByVal sID As String) As Long

Declare Function MT_M_Get_Product_ID Lib "MT_API.dll" (ByVal ADev As Long,ByVal sID As String) As Long

'//��ȡSN
Declare Function MT_Get_Product_SN Lib "MT_API.dll" (ByVal sSN As String) As Long

Declare Function MT_M_Get_Product_SN Lib "MT_API.dll" (ByVal ADev As Long,ByVal sSN As String) As Long

'//��ȡSN2
Declare Function MT_Get_Product_SN2 Lib "MT_API.dll" (ByVal sSN As Long) As Long

Declare Function MT_M_Get_Product_SN2 Lib "MT_API.dll" (ByVal ADev As Long,ByVal sSN As Long) As Long

'//��ȡSN3
Declare Function MT_Get_Product_SN3 Lib "MT_API.dll" (ByVal sSN As String) As Long

Declare Function MT_M_Get_Product_SN3 Lib "MT_API.dll" (ByVal ADev As Long,ByVal sSN As String) As Long

'//��ȡ�̼��汾��
Declare Function MT_Get_Product_Version Lib "MT_API.dll" (ByRef pMajor As Long,ByRef pMinor As Long) As Long

Declare Function MT_M_Get_Product_Version Lib "MT_API.dll" (ByVal ADev As Long,ByRef pMajor As Long,ByRef pMinor As Long) As Long

'//��ȡ�̼��汾��
Declare Function MT_Get_Product_Version2 Lib "MT_API.dll" (ByRef pMajor As Long,ByRef pMinor As Long,ByRef pRelease As Long,ByRef pBuild As Long) As Long

Declare Function MT_M_Get_Product_Version2 Lib "MT_API.dll" (ByVal ADev As Long,ByRef pMajor As Long,ByRef pMinor As Long,ByRef pRelease As Long,ByRef pBuild As Long) As Long

'//===================================================================
'//������
'//====================================================================
'//����
Declare Function MT_Get_Axis_Num Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Num Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//��ȡ���ٶ�
Declare Function MT_Get_Axis_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//���ü��ٶ�
Declare Function MT_Set_Axis_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//��ȡ���ٶ�
Declare Function MT_Get_Axis_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//���ü��ٶ�
Declare Function MT_Set_Axis_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//��ȡ����ģʽ
Declare Function MT_Get_Axis_Mode Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Mode Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//�����ٶ�ģʽ
Declare Function MT_Set_Axis_Mode_Velocity Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Mode_Velocity Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//����λ��ģʽ
Declare Function MT_Set_Axis_Mode_Position Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Mode_Position Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

Declare Function MT_Set_Axis_Mode_Position_Open Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Mode_Position_Open Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

Declare Function MT_Set_Axis_Mode_Position_Close Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Mode_Position_Close Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//��ȡ�ٶ�ģʽĿ���ٶ�
Declare Function MT_Get_Axis_Velocity_V_Target Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Velocity_V_Target Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//�����ٶ�ģʽĿ���ٶ�
Declare Function MT_Set_Axis_Velocity_V_Target_Abs Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Velocity_V_Target_Abs Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//�����ٶ�ģʽĿ���ٶ�
Declare Function MT_Set_Axis_Velocity_V_Target_Rel Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Velocity_V_Target_Rel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//ֹͣ�ٶ�ģʽ
Declare Function MT_Set_Axis_Velocity_Stop Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Velocity_Stop Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//��ȡλ��ģʽ����ٶ�
Declare Function MT_Get_Axis_Position_V_Max Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Position_V_Max Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//����λ��ģʽ����ٶ�
Declare Function MT_Set_Axis_Position_V_Max Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Position_V_Max Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//��ȡλ��ģʽĿ��
Declare Function MT_Get_Axis_Position_P_Target Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Position_P_Target Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//����λ��ģʽĿ��
Declare Function MT_Set_Axis_Position_P_Target_Abs Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Position_P_Target_Abs Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Axis_Position_P_Target_Rel Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Position_P_Target_Rel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//ֹͣλ��ģʽ
Declare Function MT_Set_Axis_Position_Stop Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Position_Stop Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//���ñ���������,���ڼ����ж���
Declare Function MT_Set_Axis_Position_Close_Dec_Factor Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AFactor As Single) As Long

Declare Function MT_M_Set_Axis_Position_Close_Dec_Factor Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AFactor As Single) As Long

'//����ֹͣ
Declare Function MT_Set_Axis_Halt Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Halt Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

Declare Function MT_Set_Axis_Halt_All Lib "MT_API.dll" () As Long

Declare Function MT_M_Set_Axis_Halt_All Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//////////////////////////////////////////////////////////////
'///  ״̬���
'///  //////////////////////////////////////////////////////
'//��ȡ��ǰ�ٶ�
Declare Function MT_Get_Axis_V_Now Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_V_Now Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//��ȡ��ǰ����λ��
Declare Function MT_Get_Axis_P_Now Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_P_Now Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Get_Axis_Software_P_Now Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Software_P_Now Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Get_Axis_Software_P Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Software_P Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//��������λ��
Declare Function MT_Set_Axis_P_Now Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_P_Now Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Axis_Software_P Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Software_P Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Axis_Software_P_Now Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Software_P_Now Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Get_Axis_Status Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pRun As Byte,ByRef pDir As Byte,ByRef pNeg As Byte,ByRef pPos As Byte,ByRef pZero As Byte,ByRef pMode As Byte) As Long

Declare Function MT_M_Get_Axis_Status Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pRun As Byte,ByRef pDir As Byte,ByRef pNeg As Byte,ByRef pPos As Byte,ByRef pZero As Byte,ByRef pMode As Byte) As Long

Declare Function MT_Get_Axis_Status2 Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pRun As Long,ByRef pDir As Long,ByRef pNeg As Long,ByRef pPos As Long,ByRef pZero As Long,ByRef pMode As Long) As Long

Declare Function MT_M_Get_Axis_Status2 Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pRun As Long,ByRef pDir As Long,ByRef pNeg As Long,ByRef pPos As Long,ByRef pZero As Long,ByRef pMode As Long) As Long

Declare Function MT_Get_Axis_Status_Run Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pRun As Long) As Long

Declare Function MT_M_Get_Axis_Status_Run Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pRun As Long) As Long

Declare Function MT_Get_Axis_Status_Dir Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pDir As Long) As Long

Declare Function MT_M_Get_Axis_Status_Dir Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pDir As Long) As Long

Declare Function MT_Get_Axis_Status_Neg Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pNeg As Long) As Long

Declare Function MT_M_Get_Axis_Status_Neg Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pNeg As Long) As Long

Declare Function MT_Get_Axis_Status_Pos Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pPos As Long) As Long

Declare Function MT_M_Get_Axis_Status_Pos Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pPos As Long) As Long

Declare Function MT_Get_Axis_Status_Zero Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pZero As Long) As Long

Declare Function MT_M_Get_Axis_Status_Zero Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pZero As Long) As Long

Declare Function MT_Get_Axis_Status_Mode Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pMode As Long) As Long

Declare Function MT_M_Get_Axis_Status_Mode Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pMode As Long) As Long

'//����0λģʽ
Declare Function MT_Set_Axis_Mode_Home Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Mode_Home Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

Declare Function MT_Set_Axis_Mode_Home_Home_Switch Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Mode_Home_Home_Switch Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

Declare Function MT_Set_Axis_Mode_Home_Encoder_Index Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Mode_Home_Encoder_Index Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

Declare Function MT_Set_Axis_Mode_Home_Encoder_Home_Switch Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Mode_Home_Encoder_Home_Switch Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

Declare Function MT_Set_Axis_Mode_Home_Home_Zero Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Mode_Home_Home_Zero Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//����0λģʽĿ���ٶ�
Declare Function MT_Set_Axis_Home_V Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Home_V Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//ֹͣ0λģʽ
Declare Function MT_Set_Axis_Home_Stop Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Home_Stop Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//������λ
'//����������λֵ
Declare Function MT_Set_Axis_Software_Limit_Neg_Value Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Software_Limit_Neg_Value Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����������λֵ
Declare Function MT_Set_Axis_Software_Limit_Pos_Value Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Software_Limit_Pos_Value Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//ʹ��������λģʽ
Declare Function MT_Set_Axis_Software_Limit_Enable Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Software_Limit_Enable Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//ֹͣ������λģʽ
Declare Function MT_Set_Axis_Software_Limit_Disable Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Software_Limit_Disable Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'////////////////////////////////////////////////////////////////////////
'//�洢��
'//��ȡ�洢������
Declare Function MT_Get_System_Mem_Len Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_System_Mem_Len Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//��ȡ�洢������
Declare Function MT_Get_System_Mem_Data Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Byte) As Long

Declare Function MT_M_Get_System_Mem_Data Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Byte) As Long

'//���ô洢������
Declare Function MT_Set_System_Mem_Data Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Byte) As Long

Declare Function MT_M_Set_System_Mem_Data Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Byte) As Long

'//====================================================================
'// ϵͳ�����洢��
'//======================================================================
'// ��ȡ�洢������
Declare Function MT_Get_Param_Mem_Len Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Param_Mem_Len Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//��ȡ�洢������
Declare Function MT_Get_Param_Mem_Data Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Byte) As Long

Declare Function MT_M_Get_Param_Mem_Data Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Byte) As Long

'//���ô洢������
Declare Function MT_Set_Param_Mem_Data Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Byte) As Long

Declare Function MT_M_Set_Param_Mem_Data Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Byte) As Long

'//====================================================================
'//�������
'//======================================================================
'//ͨ����
Declare Function MT_Get_Optic_In_Num Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Optic_In_Num Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//���㸴�õ������λ����λ
Declare Function MT_Get_Optic_In_Basic_Num Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Optic_In_Basic_Num Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//��ȡ��ͨ��ֵ
Declare Function MT_Get_Optic_In_Single Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Optic_In_Single Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//��ȡ����ͨ��ֵ
Declare Function MT_Get_Optic_In_All Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Optic_In_All Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//====================================================================
'//������
'//======================================================================
'//ͨ����
Declare Function MT_Get_Optic_Out_Num Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Optic_Out_Num Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//���õ�ͨ��ֵ
Declare Function MT_Set_Optic_Out_Single Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Optic_Out_Single Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//��������ͨ��ֵ
Declare Function MT_Set_Optic_Out_All Lib "MT_API.dll" (ByVal Value As Long) As Long

Declare Function MT_M_Set_Optic_Out_All Lib "MT_API.dll" (ByVal ADev As Long,ByVal Value As Long) As Long

'//��ȡ��ͨ��ֵ
Declare Function MT_Get_Optic_Out_Single Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Optic_Out_Single Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//��ȡ����ͨ��ֵ
Declare Function MT_Get_Optic_Out_All Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Optic_Out_All Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//====================================================================
'//OC���
'//======================================================================
'//ͨ����
Declare Function MT_Get_OC_Out_Num Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_OC_Out_Num Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//���õ�ͨ��ֵ
Declare Function MT_Set_OC_Out_Single Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_OC_Out_Single Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//��������ͨ��ֵ
Declare Function MT_Set_OC_Out_All Lib "MT_API.dll" (ByVal Value As Long) As Long

Declare Function MT_M_Set_OC_Out_All Lib "MT_API.dll" (ByVal ADev As Long,ByVal Value As Long) As Long

'//��ȡ��ͨ��ֵ
Declare Function MT_Get_OC_Out_Single Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_OC_Out_Single Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//��ȡ����ͨ��ֵ
Declare Function MT_Get_OC_Out_All Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_OC_Out_All Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//ֱ�߲岹���
'//����ֱ�߲岹���ἰ�ٶ�
Declare Function MT_Set_Axis_Line_Axis Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Axis_ID0 As Long,ByVal Axis_ID1 As Long) As Long

Declare Function MT_M_Set_Axis_Line_Axis Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Axis_ID0 As Long,ByVal Axis_ID1 As Long) As Long

'//����ֱ�߲岹���ٶ�
Declare Function MT_Set_Axis_Line_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Line_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����ֱ�߲岹���ٶ�
Declare Function MT_Set_Axis_Line_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Line_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����ֱ�߲岹�ٶ�
Declare Function MT_Set_Axis_Line_V Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Line_V Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����ֱ�߲岹����
Declare Function MT_Set_Axis_Line_Run Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Line_Run Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//����ֱ�߲岹ֹͣ
Declare Function MT_Set_Axis_Line_Stop Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Line_Stop Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//����ֱ�߲岹��ͣ
Declare Function MT_Set_Axis_Line_Halt Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Line_Halt Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//����ֱ�߲岹����ƶ�Ŀ��
Declare Function MT_Set_Axis_Line_Rel Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_M_Set_Axis_Line_Rel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

'//����ֱ�߲岹�����ƶ�Ŀ��
Declare Function MT_Set_Axis_Line_Abs Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_M_Set_Axis_Line_Abs Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

'//����ֱ�߲岹����
Declare Function MT_Set_Axis_Line_Run_Rel Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_M_Set_Axis_Line_Run_Rel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_Set_Axis_Line_Run_Abs Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_M_Set_Axis_Line_Run_Abs Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

'//��ȡֱ�߲岹ģ��
Declare Function MT_Get_Axis_Line_Num Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Line_Num Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//�岹�˶�״̬
Declare Function MT_Get_Axis_Line_Status Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Line_Status Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//�岹��
Declare Function MT_Get_Axis_Line_Axis Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pID0 As Long,ByRef pID1 As Long) As Long

Declare Function MT_M_Get_Axis_Line_Axis Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pID0 As Long,ByRef pID1 As Long) As Long

'//�岹���ٶ�
Declare Function MT_Get_Axis_Line_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Line_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//�岹���ٶ�
Declare Function MT_Get_Axis_Line_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Line_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//�岹�ٶ�
Declare Function MT_Get_Axis_Line_V Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Line_V Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//====================================================================
'//AD����
'//======================================================================
'//ͨ����
Declare Function MT_Get_AD_Num Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_AD_Num Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//��ȡ��ͨ��ֵ
Declare Function MT_Get_AD_Data Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_AD_Data Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Get_Board_T Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Board_T Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//2020 01 05 �ⲿ�¶ȴ�����
Declare Function MT_Get_T_Num Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_T_Num Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

Declare Function MT_Get_T_Float Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Single) As Long

Declare Function MT_M_Get_T_Float Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Single) As Long

Declare Function MT_Get_T Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_T Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//2020 01 05 PWM����
Declare Function MT_Get_PWM_Num Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_PWM_Num Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

Declare Function MT_Set_PWM_F Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_PWM_F Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Get_PWM_F Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_PWM_F Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Set_PWM_F_Float Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Single) As Long

Declare Function MT_M_Set_PWM_F_Float Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Single) As Long

Declare Function MT_Get_PWM_F_Float Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Single) As Long

Declare Function MT_M_Get_PWM_F_Float Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Single) As Long

Declare Function MT_Set_PWM01 Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_PWM01 Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Get_PWM01 Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_PWM01 Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Set_PWM001 Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_PWM001 Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Get_PWM001 Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_PWM001 Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Set_PWM_Float Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Single) As Long

Declare Function MT_M_Set_PWM_Float Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Single) As Long

Declare Function MT_Get_PWM_Float Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Single) As Long

Declare Function MT_M_Get_PWM_Float Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Single) As Long

'//================================================================
'//Բ���岹
'//================================================================
'//����Բ���岹���ἰ�ٶ�
Declare Function MT_Set_Axis_Circle_Axis Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Axis_ID0 As Long,ByVal Axis_ID1 As Long) As Long

Declare Function MT_M_Set_Axis_Circle_Axis Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Axis_ID0 As Long,ByVal Axis_ID1 As Long) As Long

'//����Բ���岹���ٶ�
Declare Function MT_Set_Axis_Circle_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Circle_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����Բ���岹���ٶ�
Declare Function MT_Set_Axis_Circle_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Circle_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����Բ���岹�ٶ�
Declare Function MT_Set_Axis_Circle_V Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Circle_V Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����Բ���岹���� ˳ʱ��  Բ������ģʽ
Declare Function MT_Set_Axis_Circle_R_CW_Run_Rel Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_M_Set_Axis_Circle_R_CW_Run_Rel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_Set_Axis_Circle_R_CW_Run_Abs Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_M_Set_Axis_Circle_R_CW_Run_Abs Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

'//����Բ���岹���� ��ʱ��   Բ������
Declare Function MT_Set_Axis_Circle_R_CCW_Run_Rel Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_M_Set_Axis_Circle_R_CCW_Run_Rel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_Set_Axis_Circle_R_CCW_Run_Abs Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_M_Set_Axis_Circle_R_CCW_Run_Abs Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

'//����Բ���岹ֹͣ
Declare Function MT_Set_Axis_Circle_Stop Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Circle_Stop Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//����Բ���岹��ͣ
Declare Function MT_Set_Axis_Circle_Halt Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Axis_Circle_Halt Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//��ȡԲ���岹ģ��
Declare Function MT_Get_Axis_Circle_Num Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Circle_Num Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//�岹�˶�״̬
Declare Function MT_Get_Axis_Circle_Status Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Circle_Status Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//�岹��
Declare Function MT_Get_Axis_Circle_Axis Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pID0 As Long,ByRef pID1 As Long) As Long

Declare Function MT_M_Get_Axis_Circle_Axis Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pID0 As Long,ByRef pID1 As Long) As Long

'//�岹���ٶ�
Declare Function MT_Get_Axis_Circle_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Circle_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//�岹���ٶ�
Declare Function MT_Get_Axis_Circle_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Circle_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//�岹�ٶ�
Declare Function MT_Get_Axis_Circle_V Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Circle_V Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//2014 04 09���䶨�� ������ʼ�ٶ��޸� ���Ӷ�������ֱ�߲岹
Declare Function MT_Set_Axis_Home_V_Start Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Home_V_Start Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Axis_Home_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Home_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Axis_Home_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Home_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Get_Axis_Home_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Home_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Get_Axis_Home_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Home_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Set_Axis_Velocity_V_Start Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Velocity_V_Start Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Axis_Velocity_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Velocity_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Axis_Velocity_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Velocity_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Get_Axis_Velocity_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Velocity_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Get_Axis_Velocity_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Velocity_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Set_Axis_Position_V_Start Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Position_V_Start Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Axis_Position_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Position_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Axis_Position_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Position_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Get_Axis_Position_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Position_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Get_Axis_Position_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Axis_Position_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Set_Axis_Line_V_Start Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Line_V_Start Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Axis_Circle_V_Start Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Axis_Circle_V_Start Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Axis_Line_X_Run_Rel Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AAxis_Num As Long,ByVal pAxis As Long,ByVal pTarget As Long) As Long

Declare Function MT_M_Set_Axis_Line_X_Run_Rel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AAxis_Num As Long,ByVal pAxis As Long,ByVal pTarget As Long) As Long

Declare Function MT_Set_Axis_Line_X_Run_Abs Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AAxis_Num As Long,ByVal pAxis As Long,ByVal pTarget As Long) As Long

Declare Function MT_M_Set_Axis_Line_X_Run_Abs Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AAxis_Num As Long,ByVal pAxis As Long,ByVal pTarget As Long) As Long

Declare Function MT_Set_Axis_Line_X_Target_Rel Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AAxisID As Long,ByVal ATarget As Long) As Long

Declare Function MT_M_Set_Axis_Line_X_Target_Rel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AAxisID As Long,ByVal ATarget As Long) As Long

Declare Function MT_Set_Axis_Line_X_Target_Abs Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AAxisID As Long,ByVal ATarget As Long) As Long

Declare Function MT_M_Set_Axis_Line_X_Target_Abs Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AAxisID As Long,ByVal ATarget As Long) As Long

Declare Function MT_Set_Axis_Line_X_Axis Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AAxisID As Long,ByVal AAxis As Long) As Long

Declare Function MT_M_Set_Axis_Line_X_Axis Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AAxisID As Long,ByVal AAxis As Long) As Long

Declare Function MT_Set_Axis_Line_X_Count Lib "MT_API.dll" (ByVal AObj As Integer,ByVal ANum As Long) As Long

Declare Function MT_M_Set_Axis_Line_X_Count Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal ANum As Long) As Long

'//PLC��صĺ���
'//PLC��ص�ָ����
'//�������洢����С
Declare Function MT_Get_PLC_Var_Num Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_PLC_Var_Num Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//������
Declare Function MT_Get_PLC_Var_Data Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_PLC_Var_Data Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//д����
Declare Function MT_Set_PLC_Var_Data Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_PLC_Var_Data Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//��ͣPLC
Declare Function MT_Set_PLC_Pause Lib "MT_API.dll" () As Long

Declare Function MT_M_Set_PLC_Pause Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//ֹͣPLC
Declare Function MT_Set_PLC_Stop Lib "MT_API.dll" () As Long

Declare Function MT_M_Set_PLC_Stop Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//����PLC����
Declare Function MT_Set_PLC_Run Lib "MT_API.dll" () As Long

Declare Function MT_M_Set_PLC_Run Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//����PLC�������
Declare Function MT_Set_PLC_Data Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Byte) As Long

Declare Function MT_M_Set_PLC_Data Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Byte) As Long

'//��ȡPLC��������С
Declare Function MT_Get_PLC_Code_Size Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_PLC_Code_Size Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//2017 01 30 PLC V6 Add
'//��ȡ�������
'//PLC������
Declare Function MT_Get_PLC_Task_Count Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_PLC_Task_Count Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//PLC����״̬
Declare Function MT_Get_PLC_Task_Status Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_PLC_Task_Status Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//�����ָ�
Declare Function MT_Get_PLC_Var_Seg Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_PLC_Var_Seg Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//��������
Declare Function MT_Get_PLC_Var_Used Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_PLC_Var_Used Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//PLC״̬
Declare Function MT_Get_PLC_Status Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_PLC_Status Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//ȫ��״̬
Declare Function MT_Get_PLC_Tasks_Status Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_PLC_Tasks_Status Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//Axis Ratio
Declare Function MT_Get_PLC_Axis_Ratio Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Single) As Long

Declare Function MT_M_Get_PLC_Axis_Ratio Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Single) As Long

Declare Function MT_Get_PLC_Encoder_Ratio Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Single) As Long

Declare Function MT_M_Get_PLC_Encoder_Ratio Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Single) As Long

'//��ָ��ģʽ
'//����Stream
Declare Function MT_Set_Stream_Run Lib "MT_API.dll" () As Long

Declare Function MT_M_Set_Stream_Run Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//ֹͣStream
Declare Function MT_Set_Stream_Stop Lib "MT_API.dll" () As Long

Declare Function MT_M_Set_Stream_Stop Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//��ͣStream
Declare Function MT_Set_Stream_Pause Lib "MT_API.dll" () As Long

Declare Function MT_M_Set_Stream_Pause Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//���Stream
Declare Function MT_Set_Stream_Clear Lib "MT_API.dll" () As Long

Declare Function MT_M_Set_Stream_Clear Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//��ȡʣ��ռ�
Declare Function MT_Get_Stream_Space Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Stream_Space Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//��ȡ�ܿռ�
Declare Function MT_Get_Stream_Total Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Stream_Total Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//��ȡ�ܿռ�
Declare Function MT_Get_Stream_Count Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Stream_Count Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//����ָ����broadcast�д洢����Stream����
Declare Function MT_Set_Stream_Delay Lib "MT_API.dll" (ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Delay Lib "MT_API.dll" (ByVal ADev As Long,ByVal Value As Long) As Long

'//ֱ�߲岹�˶�
'//����ֱ�߲岹���ٶ�
Declare Function MT_Set_Stream_Line_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Line_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����ֱ�߲岹���ٶ�
Declare Function MT_Set_Stream_Line_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Line_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����ֱ�߲岹�ٶ�
Declare Function MT_Set_Stream_Line_V_Max Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Line_V_Max Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����ֱ�߲岹�����ٶ�
Declare Function MT_Set_Stream_Line_V_Start Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Line_V_Start Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����ֱ�߲岹ֹͣ
Declare Function MT_Set_Stream_Line_Stop Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Stream_Line_Stop Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//����ֱ�߲岹��ͣ
Declare Function MT_Set_Stream_Line_Halt Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Stream_Line_Halt Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//����ֱ�߲岹
Declare Function MT_Set_Stream_Line_X_Run_Rel Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AAxis_Num As Long,ByVal pAxis As Long,ByVal pTarget As Long) As Long

Declare Function MT_M_Set_Stream_Line_X_Run_Rel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AAxis_Num As Long,ByVal pAxis As Long,ByVal pTarget As Long) As Long

Declare Function MT_Set_Stream_Line_X_Run_Abs Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AAxis_Num As Long,ByVal pAxis As Long,ByVal pTarget As Long) As Long

Declare Function MT_M_Set_Stream_Line_X_Run_Abs Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AAxis_Num As Long,ByVal pAxis As Long,ByVal pTarget As Long) As Long

'//����Բ���岹���ἰ�ٶ�
Declare Function MT_Set_Stream_Circle_Axis Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Axis_ID0 As Long,ByVal Axis_ID1 As Long) As Long

Declare Function MT_M_Set_Stream_Circle_Axis Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Axis_ID0 As Long,ByVal Axis_ID1 As Long) As Long

'//����Բ���岹���ٶ�
Declare Function MT_Set_Stream_Circle_Acc Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Circle_Acc Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����Բ���岹���ٶ�
Declare Function MT_Set_Stream_Circle_Dec Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Circle_Dec Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����Բ���岹�ٶ�
Declare Function MT_Set_Stream_Circle_V_Max Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Circle_V_Max Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����Բ���岹�����ٶ�
Declare Function MT_Set_Stream_Circle_V_Start Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Circle_V_Start Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����Բ���岹���� ˳ʱ��  Բ������ģʽ
Declare Function MT_Set_Stream_Circle_R_CW_Run_Rel Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_M_Set_Stream_Circle_R_CW_Run_Rel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_Set_Stream_Circle_R_CW_Run_Abs Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_M_Set_Stream_Circle_R_CW_Run_Abs Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

'//����Բ���岹���� ��ʱ��   Բ������
Declare Function MT_Set_Stream_Circle_R_CCW_Run_Rel Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_M_Set_Stream_Circle_R_CCW_Run_Rel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_Set_Stream_Circle_R_CCW_Run_Abs Lib "MT_API.dll" (ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

Declare Function MT_M_Set_Stream_Circle_R_CCW_Run_Abs Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal AR As Long,ByVal Axis_Target0 As Long,ByVal Axis_Target1 As Long) As Long

'//����Բ���岹ֹͣ
Declare Function MT_Set_Stream_Circle_Stop Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Stream_Circle_Stop Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//����Բ���岹��ͣ
Declare Function MT_Set_Stream_Circle_Halt Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Stream_Circle_Halt Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

Declare Function MT_Set_Stream_Wait_Line Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Stream_Wait_Line Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

Declare Function MT_Set_Stream_Wait_Circle Lib "MT_API.dll" (ByVal AObj As Integer) As Long

Declare Function MT_M_Set_Stream_Wait_Circle Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer) As Long

'//���õ�ͨ��ֵ
Declare Function MT_Set_Stream_OC_Out_Single Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_OC_Out_Single Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//��������ͨ��ֵ
Declare Function MT_Set_Stream_OC_Out_All Lib "MT_API.dll" (ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_OC_Out_All Lib "MT_API.dll" (ByVal ADev As Long,ByVal Value As Long) As Long

'//���õ�ͨ��ֵ
Declare Function MT_Set_Stream_Optic_Out_Single Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Optic_Out_Single Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//��������ͨ��ֵ
Declare Function MT_Set_Stream_Optic_Out_All Lib "MT_API.dll" (ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Optic_Out_All Lib "MT_API.dll" (ByVal ADev As Long,ByVal Value As Long) As Long

'//���ٹ���
Declare Function MT_Set_Stream_Dec_Enable Lib "MT_API.dll" () As Long

Declare Function MT_M_Set_Stream_Dec_Enable Lib "MT_API.dll" (ByVal ADev As Long) As Long

Declare Function MT_Set_Stream_Dec_Disable Lib "MT_API.dll" () As Long

Declare Function MT_M_Set_Stream_Dec_Disable Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//2016 08 20 ���ӵȴ����빦��
'//�ȴ�Optic_In״̬
Declare Function MT_Set_Stream_Wait_Optic_In Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Wait_Optic_In Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//����Stream,������У�鹦��
Declare Function MT_Set_Stream_Run_Check Lib "MT_API.dll" () As Long

Declare Function MT_M_Set_Stream_Run_Check Lib "MT_API.dll" (ByVal ADev As Long) As Long

'//2019 09 15 running id for UI
Declare Function MT_Set_Stream_Run_ID Lib "MT_API.dll" (ByVal Value As Long) As Long

Declare Function MT_M_Set_Stream_Run_ID Lib "MT_API.dll" (ByVal ADev As Long,ByVal Value As Long) As Long

Declare Function MT_Get_Stream_Run_ID Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Stream_Run_ID Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

'//����������
Declare Function MT_Get_Encoder_Num Lib "MT_API.dll" (ByRef pValue As Long) As Long

Declare Function MT_M_Get_Encoder_Num Lib "MT_API.dll" (ByVal ADev As Long,ByRef pValue As Long) As Long

Declare Function MT_Get_Encoder_Pos Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Encoder_Pos Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Set_Encoder_Pos Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Encoder_Pos Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Encoder_Z_Polarity Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Encoder_Z_Polarity Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Encoder_Dir_Polarity Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Encoder_Dir_Polarity Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Get_Encoder_Index_Line_Count Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Encoder_Index_Line_Count Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Set_Encoder_Over_Enable Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Encoder_Over_Enable Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Encoder_Over_Max Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Encoder_Over_Max Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Encoder_Over_Stable Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Encoder_Over_Stable Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

'//�������������ϴ�
Declare Function MT_Get_Push_Data Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Push_Data Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//2021 04 24  ͬ��������ؽӿ�
Declare Function MT_Set_Trigger_Enable Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Trigger_Enable Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Trigger_Start Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Trigger_Start Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Trigger_End Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Trigger_End Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Trigger_Step Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Trigger_Step Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Trigger_Width Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Trigger_Width Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Trigger_Channel Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Trigger_Channel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Set_Trigger_Polarity Lib "MT_API.dll" (ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_M_Set_Trigger_Polarity Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByVal Value As Long) As Long

Declare Function MT_Get_Trigger_Enable Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Trigger_Enable Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Get_Trigger_Start Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Trigger_Start Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Get_Trigger_End Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Trigger_End Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Get_Trigger_Step Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Trigger_Step Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Get_Trigger_Width Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Trigger_Width Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Get_Trigger_Channel Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Trigger_Channel Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_Get_Trigger_Polarity Lib "MT_API.dll" (ByVal AObj As Integer,ByRef pValue As Long) As Long

Declare Function MT_M_Get_Trigger_Polarity Lib "MT_API.dll" (ByVal ADev As Long,ByVal AObj As Integer,ByRef pValue As Long) As Long

'//�������㹫ʽ
'//mm to pluse
Declare Function MT_Help_Step_Line_Real_To_Steps Lib "MT_API.dll" (ByVal AStepAngle As Double,ByVal ADiv As Long,ByVal APitch As Double,ByVal ALineRatio As Double,ByVal AValue As Double) As Long

Declare Function MT_Help_Step_Circle_Real_To_Steps Lib "MT_API.dll" (ByVal AStepAngle As Double,ByVal ADiv As Long,ByVal ACircleRatio As Double,ByVal AValue As Double) As Long

'//pluse to mm
Declare Function MT_Help_Step_Line_Steps_To_Real Lib "MT_API.dll" (ByVal AStepAngle As Double,ByVal ADiv As Long,ByVal APitch As Double,ByVal ALineRatio As Double,ByVal AValue As Long) As Double

Declare Function MT_Help_Step_Circle_Steps_To_Real Lib "MT_API.dll" (ByVal AStepAngle As Double,ByVal ADiv As Long,ByVal ACircleRatio As Double,ByVal AValue As Long) As Double

'//Encoder
'//����������λ����
Declare Function MT_Help_Encoder_Line_Real_To_Steps Lib "MT_API.dll" (ByVal APitch As Double,ByVal ALineRatio As Double,ByVal ALineCount As Long,ByVal AValue As Double) As Long

Declare Function MT_Help_Encoder_Circle_Real_To_Steps Lib "MT_API.dll" (ByVal ACircleRatio As Double,ByVal ALineCount As Long,ByVal AValue As Double) As Long

'//pluse to mm
Declare Function MT_Help_Encoder_Line_Steps_To_Real Lib "MT_API.dll" (ByVal APitch As Double,ByVal ALineRatio As Double,ByVal ALineCount As Long,ByVal AValue As Long) As Double

Declare Function MT_Help_Encoder_Circle_Steps_To_Real Lib "MT_API.dll" (ByVal ACircleRatio As Double,ByVal ALineCount As Long,ByVal AValue As Long) As Double

'//Grating
'//����������λ����
Declare Function MT_Help_Grating_Line_Real_To_Steps Lib "MT_API.dll" (ByVal AUnit_um As Double,ByVal AValue As Double) As Long

Declare Function MT_Help_Grating_Circle_Real_To_Steps Lib "MT_API.dll" (ByVal ALineCount As Long,ByVal AValue As Double) As Long

'//pluse to mm
Declare Function MT_Help_Grating_Line_Steps_To_Real Lib "MT_API.dll" (ByVal AUnit_um As Double,ByVal AValue As Long) As Double

Declare Function MT_Help_Grating_Circle_Steps_To_Real Lib "MT_API.dll" (ByVal ALineCount As Long,ByVal AValue As Long) As Double

Declare Function MT_Help_Encoder_Factor Lib "MT_API.dll" (ByVal AStepAngle As Double,ByVal ADiv As Long,ByVal ALineCount As Long) As Single

'//��դ�߰�װ�ڻ�е�ϣ������ת����һ�£���Ҫ���ǻ�е��Ӱ��
Declare Function MT_Help_Grating_Line_Factor Lib "MT_API.dll" (ByVal AStepAngle As Double,ByVal ADiv As Long,ByVal APitch As Double,ByVal ALineRatio As Double,ByVal AUnit_um As Double) As Single

Declare Function MT_Help_Grating_Circle_Factor Lib "MT_API.dll" (ByVal AStepAngle As Double,ByVal ADiv As Long,ByVal ACircleRatio As Double,ByVal ALineCount As Long) As Single

'//�����ڲ���Դ����


